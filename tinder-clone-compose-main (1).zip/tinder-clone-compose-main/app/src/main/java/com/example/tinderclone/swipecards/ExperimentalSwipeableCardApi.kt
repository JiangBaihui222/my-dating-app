package com.example.tinderclone.swipecards

annotation class ExperimentalSwipeableCardApi()
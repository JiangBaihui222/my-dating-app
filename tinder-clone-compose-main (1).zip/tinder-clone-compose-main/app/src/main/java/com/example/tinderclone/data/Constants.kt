package com.example.tinderclone.data

const val COLLECTION_USER = "user"
const val COLLECTION_CHAT = "chat"
const val COLLECTION_MESSAGES = "messages"